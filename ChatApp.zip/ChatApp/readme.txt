
NAME: ZHIMING ZHANG
UCID: 10170481



STEP1: Download

STEP2: npm install

STEP3: node server


