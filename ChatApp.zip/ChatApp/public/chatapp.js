

var name;
var color = "rgb(0,0,0)";

// Initializer the chat app
window.onload = function(){
	var chatapp = new ChatAp();
	chatapp.init();
};

// define the var of ChatAp
var ChatAp = function(){
	this.socket = null;
};

ChatAp.prototype = {

	init: function(){
		var that = this;

		//Establish a socket connection with the server
		this.socket = io.connect();

		//Monitor socket connect event, this event indicates that the connection has been established
		this.socket.on('connect',function(){
			document.getElementById('info').textContent = 'Please enter your name';
			document.getElementById('nickWrapper').style.display = 'block';
			document.getElementById('nicknameInput').focus();
		});

		//login success
		this.socket.on('loginSuccess', function(){
			document.title = 'Chat app: ' + document.getElementById('nicknameInput').value;
			document.getElementById('loginWrapper').style.display = 'none';
			document.getElementById('inputMsg').focus();
		});

		//The number of people in the system is updated, prompting users to join or leave
		this.socket.on('system', function(nickname, count, type){
			that._systemInfo(nickname, count, type);
		});

		this.socket.on('system1', function(nickname, count, type){
			that._system1Info(nickname, count, type);
		});

		//Receive new message
		this.socket.on('newMsg', function(nickname, msg){
			that._displayNewMsg(nickname, msg, 'newMsg');
			// alert(nickname + ': ' + msg);
		});


		//Set the login button and nicknameInput monitoring event (click&keyup) login
		document.getElementById('loginBtn').addEventListener('click', function(){
			var nickname = document.getElementById('nicknameInput').value.trim();
			var info = document.getElementById('info');
			var nicknameInput = document.getElementById('nicknameInput');
			
				
			if (nickname.length == 0 ){
				//if user not enter the user name
				info.textContent = 'Nickname illegal, try another';
				info.style.color = 'red';
				nicknameInput.value = '';
				nicknameInput.focus();
			}else{
				//Username is legal
				that.socket.emit('login', nickname);

			}
		}, false);


		//Send button and inputMsg listen event
		document.getElementById('sendBtn').addEventListener('click', function(){
			//1. Get user input
			//2. Check whether the length limit is exceeded
			//3. Broadcast directly after passing detection
			var inputMsg = document.getElementById('inputMsg');
			var msg = inputMsg.value.replace('\n','');
			if (msg == ''){
				inputMsg.focus();
				return;
			}
			
			that.socket.emit('msgSend', msg);
			inputMsg.value = '';
			that._displayNewMsg('', msg, 'myMsg');
			
		}, false);

	},

	_displayNewMsg: function(nickname, msg, who){
		// get the chat box
		var historyMsg = document.getElementById('historyMsg');
		// shent the lable
		var p = document.createElement('p');

		p.setAttribute('class',who);

		var span_timespan = document.createElement('span');
		span_timespan.setAttribute('class','timespan');
		var time = '' + new Date().toTimeString().substr(0, 8) + '  ';
		span_timespan.textContent = time;

		var span_nickname = document.createElement('span');
		span_nickname.setAttribute('class','nickname' );
		span_nickname.textContent = nickname;

		var text = document.createTextNode(msg);

		p.appendChild(span_timespan);
		p.appendChild(span_nickname);
		p.appendChild(text);

		historyMsg.appendChild(p);

		historyMsg.scrollTop = historyMsg.scrollHeight;

		msg = this._sEmoji(msg);

	},

	/*socket.on('nickname', function(data) {
        name = data.nickname;
        color = data.color;
        document.cookie = `name=${nickname}`;
	}),
	
	socket.on('has cookie or not', function() {
        var value = getCookie("nikiname");
        if (value){
            socket.emit('has cookie or not', {c_nikiname: value})
        }
        else {
            socket.emit('has cookie or not', {c_nikiname: null})
        }
    });*/

	_systemInfo: function(nickname, count, type){
		
		document.getElementById('status').textContent = count;
			
		var historyMsg = document.getElementById('historyMsg');
		var p = document.createElement('p');
		var span = document.createElement('span');
		var text;
		if (type == 'login'){
			text = document.createTextNode(' add in to the chatroom');
			p.style.color = '#0E9B01'
			span.style.color = '#0E9B01'
		}else if (type == 'logout'){
			text = document.createTextNode(' left the chatroom');
			p.style.color = '#EB0E00'
			span.style.color = '#EB0E00'
		}

		p.setAttribute('class','system');
		span.setAttribute('class','nickname');
		span.textContent = nickname;

		p.appendChild(span);
		p.appendChild(text);


		historyMsg.appendChild(p);
	}
};

//emjio
/*$('.emoji').on('click',function(){
	$('#content').emoji({
		// button for emoji
		button = '.emoji',
		showTab: false,
		animation: 'slide',
		position: 'topLeft',
		icons: [{
			name: "qq",
			path: "lib/img/emoji/",
			maxNum: 91,
			excludeNums: [41, 45, 54],
			file: ".gif"
		}]
	})
}) */

/* reference: part learn from: 
1. https://www.bilibili.com/video/BV1yi4y1t7yD?p=2
2. https://juejin.im/post/6844903847014449165
3. https://waylau.com/node.js-websocket-chat/
4. https://www.cnblogs.com/Wayou/p/hichat_built_with_nodejs_socket.html
5. https://getbootstrap.com/docs/4.1/layout/grid/
*/ 




