//Create server, page response
var express = require('express');
var app = express();
var server = require('http').createServer(app);
//Introduce the socket.io module and bind it to the server
var io = require('socket.io').listen(server);

//Save the nicknames of all online users
var users = [];

app.use('/',express.static(__dirname + "/public"));

//socket
io.on('connection', function(socket){

	//console.log('An user connected.');


	socket.on('login', function(nickname){

		//check the user already have or not
		if (users.indexOf(nickname) > -1){
			socket.emit('loginFailed');
		}else{
			// socket.userIndex = users.length;
			socket.nickname = nickname;
			users.push(nickname);
			console.log(nickname + ' is online, total: ' + users.length);
			socket.emit('loginSuccess');
			//Send the nickname of the currently logged-in user to all clients connected to the server
			io.sockets.emit('system', nickname, users.length, 'login');
		}

	});

	//disonniction and renew the information
	//Broadcast system events
	socket.on('disconnect', function(){
		var index = users.indexOf(socket.nickname);
		users.splice(index, 1);
		//let all user know that 
		io.sockets.emit('system', socket.nickname, users.length, 'logout');

		//test
		console.log(socket.nickname + ' is disconnected.');
		console.log(users);
	});

	// get the new meesage
	socket.on('msgSend',function(msg){
		socket.broadcast.emit('newMsg', socket.nickname, msg);
	});

});

server.listen(3000);
console.log("Server has started.");


/* reference: part learn from: 
1. https://www.bilibili.com/video/BV1yi4y1t7yD?p=2
2. https://juejin.im/post/6844903847014449165
3. https://waylau.com/node.js-websocket-chat/
4. https://www.cnblogs.com/Wayou/p/hichat_built_with_nodejs_socket.html
5. https://getbootstrap.com/docs/4.1/layout/grid/
6. https://socket.io/get-started/chat/
*/ 
